//string file
#ifndef STRING
#define STRING

/*Function declarations*/
void str_trim_lf (char*, int);//remove extra whitespaces 
void str_overwrite_stdout();//overwrite the current message

#endif // STRING


