//start file
#ifndef PROTO//allows for conditional compilation i.e. its the first file to be compiled
#define PROTO
//For macros, use ALL_CAPS seperated by underscore

#define LENGTH_NAME 31//username length
#define LENGTH_MSG 101//receiver message length
#define LENGTH_SEND 201//sender message length
#define IP_ADDRESS 16//length of IP address
#define SOCK_CREATE_FAIL 0//socket creation failure
#define SEND_FAIL 0//send function failure
#define RECEIVE_FAIL 0//receive function failure
#define PORT 8888//port number
#define IP "127.0.0.1"//IP address
#define MEETING_NAME "group3"//Meeting name

#define MEET_PASSWORD "abc"//password for client
#define PASSWORD_LENGTH 6//length of passoword

#define USERNAME_SERVER "server"//username of server
#define PASSWORD_SERVER "123"//password of server

#endif // PROTO
